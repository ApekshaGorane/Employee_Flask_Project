from flask import *
from DBM import addEmp,get_login,selectAllEmp,deleteEmp,selectEmpById,updateEmp,deleteEmp
app=Flask(__name__)

@app.route("/")
def login1():
    d=selectAllEmp()
    return render_template("login.html")
    
@app.route("/get_login")
def login2():
    email=request.args.get('user')
    pwd=request.args.get('pwd')
    d=get_login()
    if (email,pwd) in d:
         print("Login Successfully")
         return render_template("home.html")
    else:
        print("Invalid username or password")
        return render_template("login.html")
    

@app.route("/home")
def home():
    return render_template("home.html")
   
@app.route("/reg")
def register():
    return render_template("register.html")

@app.route("/emplist")
def emplist():
    d=selectAllEmp()
    return render_template("records.html",elist=d)
    

@app.route("/addEmp",methods=["POST"])
def add_emp():
    ids=request.form["id"]
    name=request.form["name"]
    contact=request.form["contact"]
    email=request.form["email"]
    passw=request.form["pass"]

    t=(ids,name,contact,email,passw)
    addEmp(t)

    return redirect("/home")

@app.route("/update")
def update():
    id=request.args.get('id')
    d=selectEmpById(id)
    return render_template("update.html",udata=d)

@app.route("/updateEmp",methods=["POST"])
def update_emp():
    ids=request.form["id"]
    name=request.form["name"]
    contact=request.form["contact"]                 
    email=request.form["email"]                 
    passw=request.form["pass"]

    t=(name,contact,email,passw,ids)
    updateEmp(t)

    return redirect("/emplist")

@app.route("/deleteEmp")
def delete():
    ids=request.args.get('id')
    deleteEmp(ids)
    return redirect("/emplist")
if(__name__=="__main__"):
    app.run(debug=True)
